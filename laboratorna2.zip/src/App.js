// App.js

import React, { useState } from 'react';
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import './App.css';
import productImage from './assets/p.jpg';
import productImageg from './assets/g.jpg';
import productImagec from './assets/c.jpg';

const App = () => {
    const [cartItems, setCartItems] = useState([]);

    const products = [
        {
            name: "Product 1",
            price: 19.99,
            description: "Description for Product 1",
            image: productImage
        },
        {
            name: "Product 2",
            price: 29.99,
            description: "Description for Product 2",
            image: productImageg
        },
        {
            name: "Product 3",
            price: 39.99,
            description: "Description for Product 3",
            image: productImagec
        }
    ];

    const addToCart = (product) => {
        setCartItems([...cartItems, product]);
    };

    return (
        <div className="app">
            <h1 className="app-title">Welcome to Our Store</h1>
            <ProductList products={products} addToCart={addToCart} /> {/* Додаємо функцію addToCart в якості пропса */}
            <Cart cartItems={cartItems} /> {/* Передаємо список товарів у компонент кошика */}
        </div>
    );
}

export default App;
