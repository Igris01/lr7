
import React from 'react';

const ProductDetails = ({ name, price, description, image }) => {
    return (
        <div className="product-details">
            <img className="product-image" src={image} alt={name} />
            <h2 className="product-name">{name}</h2>
            <p className="product-description">{description}</p>
            <p className="product-price">Price: ${price}</p>
        </div>
    );
}

export default ProductDetails;
