import React from 'react';
import ProductCard from './ProductCard';

const ProductList = ({ products, addToCart }) => (
    <div className="product-list">
        {products.map((product, index) => (
            <div key={index} className="product-item">
                <ProductCard {...product} />
                <button onClick={() => addToCart(product)}>Додати в кошик</button>
            </div>
        ))}
    </div>
);

export default ProductList;
